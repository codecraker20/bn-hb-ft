# z3pulse Clinical Trial Portal Frontend

## Dependencies

- Node: 16.13.1
- NPM: 8.1.2
- React: 17.0.2

## Recommendations

- use yarn

## How to Run?

> Install the dependencies

```bash
$ yarn
```

> Run the development server

```bash
$ yarn start
```

---

Thank you

cheers 🤓
