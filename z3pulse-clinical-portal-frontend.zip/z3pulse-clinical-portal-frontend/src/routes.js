import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./hoc/ProtectedRoute/Index";
import RedirectIfAuth from "./hoc/RedirectIfAuth/Index";

import urls from "../src/utils/urls.json";

// components
import Layout from "./containers/Layout/Index";

// pages
import Trials from "./containers/Pages/Trials";
import Trial from "./containers/Pages/Trial";
import Profile from "./containers/Pages/Profile";
import Login from "./containers/Auth/Login";
import Signup from "./containers/Auth/Signup";
import ForgotPassword from "./containers/Auth/ForgotPassword";
import Contact from "./containers/Pages/Contact";
import ActivateSession from "./containers/Pages/ActivateSession";
import SessionActivated from "./containers/Pages/SessionActivated";

export default function MyRoutes() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route
            path={urls.activateSession.path}
            element={<ActivateSession />}
          />
          <Route
            path={urls.sessionActivated.path}
            element={<SessionActivated />}
          />
          <Route
            path={urls.home.path}
            element={<ProtectedRoute children={<Trials />} />}
          />
          <Route
            path={urls.trial.path}
            element={<ProtectedRoute children={<Trial />} />}
          />
          <Route
            path={urls.profile.path}
            element={<ProtectedRoute children={<Profile />} />}
          />
          <Route
            path={urls.contact.path}
            element={<ProtectedRoute children={<Contact />} />}
          />
          <Route
            path={urls.signup.path}
            element={<RedirectIfAuth children={<Signup />} />}
          />
          <Route
            path={urls.forgotPassword.path}
            element={<RedirectIfAuth children={<ForgotPassword />} />}
          />
          <Route
            path={urls.login.path}
            element={<RedirectIfAuth children={<Login />} />}
          />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
