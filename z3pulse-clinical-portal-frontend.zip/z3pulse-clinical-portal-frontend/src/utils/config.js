export const DOMAIN = "https://api.hub.neurobit.com";
