import { Stack, Pagination, Typography } from "@mui/material";

export default function CustomPagination({ disabled, last_page_no, limit, handlePaginationChange }) {
  
  return (
    <Stack
      direction="column"
      justifyContent="center"
      alignItems="center"
      style={{
        position: "sticky",
        bottom: "0",
        backgroundColor: "#fff",
      }}
    >
      {/* START: First Row */}
      <Stack
        px="48px"
        py="12px"
        direction="row"
        justifyContent="space-between"
        alignItems="center"
      >
        <Pagination count={last_page_no} disabled={disabled} onChange={handlePaginationChange} />
        <Typography
          style={{
            fontSize: "14px",
            fontWeight: "500",
            lineHeight: "17px",
            letterSpacing: "0em",
            textAlign: "left",
            color: "#7E7E7E",
          }}
        >
          Showing {limit} results
        </Typography>
      </Stack>
      {/* END: First Row */}
    </Stack>
  );
}
