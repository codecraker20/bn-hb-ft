export default function Footer() {
  return (
    <footer style={{ marginTop: "100px" }}>
      <center>MySite 2021</center>
    </footer>
  );
}
