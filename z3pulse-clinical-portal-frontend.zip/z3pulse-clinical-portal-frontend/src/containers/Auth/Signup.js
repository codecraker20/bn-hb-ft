import { useState } from "react";
import * as React from "react";

import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

import urls from "../../utils/urls.json";
import { saveUserCredentials } from "../../utils/helpers";
import { DOMAIN } from "../../utils/config";
import { styled } from "@mui/material/styles";

// Material UI components
import {
  Box,
  Button,
  FormControl,
  Grid,
  InputLabel,
  Stack,
  TextField as TextFieldBase,
  Typography,
} from "@mui/material";

// CAROUSEL
import { useTheme } from "@mui/material/styles";
import MobileStepper from "@mui/material/MobileStepper";
import SwipeableViews from "react-swipeable-views";
import { autoPlay } from "react-swipeable-views-utils";
import carousel1 from "../../assets/carousel1.svg";
import carousel2 from "../../assets/carousel2.svg";
import carousel3 from "../../assets/carousel3.svg";

const AutoPlaySwipeableViews = autoPlay(SwipeableViews);

const images = [
  {
    heading: "START TRIALS EASILY",
    description: null,
    imgPath: carousel1,
  },
  {
    heading: "ACCESS ALL YOUR TRIALS AT ONE PLACE",
    description: null,
    imgPath: carousel2,
  },
  {
    heading: "DOWNLOAD SOPS AND SUBJECT INFO TABLE AT EASE",
    description: null,
    imgPath: carousel3,
  },
];

const TextField = styled(TextFieldBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(2),
  },
  "& .MuiInputBase-input": {
    borderBottom: "0px",
    fontSize: 16,
    padding: "10px 12px",
  },
}));

export default function Signup() {
  // local state variables
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [org, setOrg] = useState("");
  const [email, setEmail] = useState("");
  const [password1, setPassword1] = useState("");
  const [password2, setPassword2] = useState("");

  const [loading, setLoading] = useState(false);
  const [errorFirstName, setErrorFirstName] = useState(null);
  const [errorLastName, setErrorLastName] = useState(null);
  const [errorPhone, setErrorPhone] = useState(null);
  const [errorOrg, setErrorOrg] = useState(null);
  const [errorEmail, setErrorEmail] = useState(null);
  const [errorPassword1, setErrorPassword1] = useState(null);
  const [errorPassword2, setErrorPassword2] = useState(null);
  const [error, setError] = useState(null);
  // CAROUSEL
  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = images.length;
  const handleStepChange = (step) => {
    setActiveStep(step);
  };

  // react-router-dom navigator
  const navigator = useNavigate();

  const handleSubmit = async (e) => {
    // handle form submit
    e.preventDefault();

    // remove errors from state, if any
    setError(null);
    setErrorFirstName(null);
    setErrorLastName(null);
    setErrorPhone(null);
    setErrorOrg(null);
    setErrorEmail(null);
    setErrorPassword1(null);
    setErrorPassword2(null);

    // set loading to true
    setLoading(true);

    try {
      // make API request
      const response = await axios({
        url: `${DOMAIN}/auth/registration/`,
        method: "POST",
        data: {
          first_name: firstName,
          last_name: lastName,
          phone,
          org,
          email,
          password1,
          password2,
        },
      });
      // save user credentials
      saveUserCredentials(response.data);
      // redirect to home page
      navigator(urls.home.path);
    } catch (err) {
      // set loading to false
      setLoading(false);
      try {
        // fetch error
        let error_object = JSON.parse(err.request.response);

        // set error
        setErrorFirstName(
          error_object.first_name && error_object.first_name[0]
        );
        setErrorLastName(error_object.last_name && error_object.last_name[0]);
        setErrorPhone(error_object.phone && error_object.phone[0]);
        setErrorOrg(error_object.org && error_object.org[0]);
        setErrorEmail(error_object.email && error_object.email[0]);
        setErrorPassword1(error_object.password1 && error_object.password1[0]);
        setErrorPassword2(error_object.password2 && error_object.password2[0]);
        setError(
          error_object.non_field_errors && error_object.non_field_errors[0]
        );
      } catch {
        // default error message
        setError(["Unable to signup"]);
      }
    }
  };

  const handleChange = (func, value) => {
    // handle change of input values

    // remove errors from state, if anny
    setError(null);
    setErrorFirstName(null);
    setErrorLastName(null);
    setErrorPhone(null);
    setErrorOrg(null);
    setErrorEmail(null);
    setErrorPassword1(null);
    setErrorPassword2(null);

    func(value);
  };

  return (
    <Grid
      container
      style={{
        height: "100vh",
      }}
    >
      <Grid item xs={12} lg={5}>
        <Box
          px={2}
          style={{
            height: "100vh",
            backgroundColor: "#fff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Stack
            direction="column"
            spacing={1}
            py={5}
            style={{
              width: "100%",
              maxWidth: "400px",
            }}
          >
            <Typography
              style={{
                fontSize: "32px",
                fontWeight: "700",
                lineHeight: "38px",
                letterSpacing: "0em",
                textAlign: "left",
              }}
            >
              Register
            </Typography>
            <Typography
              style={{
                fontSize: "20px",
                fontWeight: "500",
                lineHeight: "24px",
                letterSpacing: "0em",
                textAlign: "left",
              }}
            >
              Welcome to Z3Pulse Clinical Portal!
            </Typography>
            <form autoComplete="off" onSubmit={handleSubmit}>
              <Stack my={2} direction="column" spacing={2}>
                <Grid container>
                  <Grid item xs={6} pr={1}>
                    <FormControl fullWidth>
                      <InputLabel shrink variant="standard">
                        Enter Your First Name
                      </InputLabel>
                      <TextField
                        error={errorFirstName ? true : false}
                        helperText={errorFirstName}
                        fullWidth
                        variant="filled"
                        placeholder="First Name"
                        type="text"
                        value={firstName}
                        onChange={(e) =>
                          handleChange(setFirstName, e.target.value)
                        }
                        InputProps={{ disableUnderline: true }}
                        required
                      />
                    </FormControl>
                  </Grid>
                  <Grid item xs={6} pl={1}>
                    <FormControl fullWidth>
                      <InputLabel shrink variant="standard">
                        Enter Your Last Name
                      </InputLabel>
                      <TextField
                        error={errorLastName ? true : false}
                        helperText={errorLastName}
                        fullWidth
                        variant="filled"
                        placeholder="Last Name"
                        type="text"
                        value={lastName}
                        onChange={(e) =>
                          handleChange(setLastName, e.target.value)
                        }
                        InputProps={{ disableUnderline: true }}
                        required
                      />
                    </FormControl>
                  </Grid>
                </Grid>
                <FormControl>
                  <InputLabel shrink variant="standard">
                    Enter Your Email ID
                  </InputLabel>
                  <TextField
                    error={errorEmail ? true : false}
                    helperText={errorEmail}
                    fullWidth
                    variant="filled"
                    placeholder="Email ID"
                    value={email}
                    onChange={(e) => handleChange(setEmail, e.target.value)}
                    type="email"
                    InputProps={{ disableUnderline: true }}
                    required
                  />
                </FormControl>
                <FormControl>
                  <InputLabel shrink variant="standard">
                    Enter Your Phone No. (Optional)
                  </InputLabel>
                  <TextField
                    error={errorPhone ? true : false}
                    helperText={errorPhone}
                    fullWidth
                    variant="filled"
                    placeholder="Phone No."
                    type="tel"
                    value={phone}
                    onChange={(e) => handleChange(setPhone, e.target.value)}
                    InputProps={{ disableUnderline: true }}
                  />
                </FormControl>
                <FormControl>
                  <InputLabel shrink variant="standard">
                    Enter Name of Your Organisation
                  </InputLabel>
                  <TextField
                    error={errorOrg ? true : false}
                    helperText={errorOrg}
                    fullWidth
                    variant="filled"
                    placeholder="Name of Your Organisation"
                    type="text"
                    value={org}
                    onChange={(e) => handleChange(setOrg, e.target.value)}
                    InputProps={{ disableUnderline: true }}
                    required
                  />
                </FormControl>
                <FormControl>
                  <InputLabel shrink variant="standard">
                    Create Password
                  </InputLabel>
                  <TextField
                    error={errorPassword1 ? true : false}
                    helperText={errorPassword1}
                    fullWidth
                    variant="filled"
                    placeholder="Password"
                    type="password"
                    value={password1}
                    onChange={(e) => handleChange(setPassword1, e.target.value)}
                    InputProps={{ disableUnderline: true }}
                    required
                  />
                </FormControl>
                <FormControl>
                  <InputLabel shrink variant="standard">
                    Confirm Password
                  </InputLabel>
                  <TextField
                    error={errorPassword2 ? true : false}
                    helperText={errorPassword2}
                    fullWidth
                    variant="filled"
                    placeholder="Password"
                    type="password"
                    value={password2}
                    onChange={(e) => handleChange(setPassword2, e.target.value)}
                    InputProps={{ disableUnderline: true }}
                    required
                  />
                </FormControl>
                {
                  // display error messages from the state, if any
                  error ? (
                    <p
                      style={{
                        color: "red",
                      }}
                    >
                      {error}
                    </p>
                  ) : null
                }
                <Button
                  disableElevation
                  disabled={loading}
                  type="submit"
                  size="large"
                  color="primary"
                  variant="contained"
                  style={{ textTransform: "none" }}
                >
                  Register
                </Button>
              </Stack>
            </form>
            <Typography
              style={{
                fontSize: "16px",
                textAlign: "center",
                borderBottom: "1px solid #CDCDCD",
                lineHeight: "0.1em",
                margin: "10px 0 20px",
              }}
            >
              <span
                style={{
                  background: "#fff",
                  padding: "0 10px",
                  color: "#2D2D2D",
                }}
              >
                OR
              </span>
            </Typography>
            <Button
              component={Link}
              to={urls.login.path}
              disableElevation
              size="large"
              color="primary"
              variant="outlined"
              style={{ textTransform: "none" }}
            >
              Log In
            </Button>
          </Stack>
        </Box>
      </Grid>
      <Grid
        item
        xs={12}
        lg={7}
        style={{
          backgroundColor: "#0B3A73",
          height: "100%",
          width: "100%",
        }}
      >
        <Box
          px={2}
          style={{
            height: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Stack
            justifyContent="center"
            alignItems="center"
            spacing={4}
            style={{
              width: "100%",
              maxWidth: "800px",
            }}
          >
            <AutoPlaySwipeableViews
              axis={theme.direction === "rtl" ? "x-reverse" : "x"}
              index={activeStep}
              onChangeIndex={handleStepChange}
              enableMouseEvents
            >
              {images.map((step, index) => (
                <div key={index}>
                  {Math.abs(activeStep - index) <= 2 ? (
                    <Box
                      component="img"
                      sx={{
                        display: "block",
                        overflow: "hidden",
                        width: "100%",
                      }}
                      src={step.imgPath}
                      alt={step.label}
                    />
                  ) : null}
                </div>
              ))}
            </AutoPlaySwipeableViews>
            <MobileStepper
              steps={maxSteps}
              position="static"
              activeStep={activeStep}
              style={{ backgroundColor: "transparent" }}
            />
            <Stack
              justifyContent="flex-start"
              alignItems="flex-start"
              spacing={2}
            >
              <Typography
                style={{
                  color: "#fff",
                  fontSize: "16px",
                  fontWeight: "600",
                  lineHeight: "19px",
                  letterSpacing: "0em",
                  textAlign: "left",
                }}
              >
                {images[activeStep].heading}{" "}
              </Typography>
              <Typography
                style={{
                  color: "#fff",
                  fontSize: "14px",
                  fontWeight: "500",
                  lineHeight: "17px",
                  letterSpacing: "0em",
                  textAlign: "left",
                }}
              >
                {images[activeStep].description}
              </Typography>
            </Stack>
          </Stack>
        </Box>
      </Grid>
    </Grid>
  );
}
