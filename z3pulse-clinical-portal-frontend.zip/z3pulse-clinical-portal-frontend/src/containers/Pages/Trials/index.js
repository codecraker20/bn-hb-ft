import { useDispatch } from "react-redux";
import { setActiveTab } from "../../../redux/utils/utilsSlice";

import { Grid, Paper, Stack, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import moment from "moment";
import axios from "axios";

import Loading from "../../../components/Blockers/Loading";
import { DOMAIN } from "../../../utils/config";
import { getAuthorization } from "../../../utils/helpers";
import AddTrial from "./AddTrial";

function Trials() {
  const [loading, setLoading] = useState(true);
  const [trials, setTrials] = useState([]);

  // react-router-dom navigator
  const navigator = useNavigate();

  // redux
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setActiveTab("trials"));
  }, [dispatch]);

  useEffect(() => {
    setLoading(true);
    axios({
      method: "GET",
      url: `${DOMAIN}/trials/`,
      headers: {
        Authorization: getAuthorization(),
      },
    })
      .then((res) => {
        setTrials(res.data.payload);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const Card = (props) => (
    <Grid item xs={2} sm={6} md={4} lg={3}>
      <Stack
        direction="column"
        style={{
          boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.07)",
          cursor: "pointer",
          height: "100%",
        }}
        onClick={() => {
          navigator(`trial/${props.id}`);
        }}
      >
        <Stack
          direction="column"
          spacing={2}
          padding="24px"
          style={{
            borderRadius: "6px 6px 0px 0px",
            height: "100%",
          }}
        >
          <Typography
            style={{
              fontSize: "20px",
              fontWeight: "600",
              lineHeight: "24px",
              letterSpacing: "0em",
              textAlign: "left",
              color: "#2D2D2D",
            }}
          >
            {props.name}
          </Typography>
          <Typography
            style={{
              fontSize: "14px",
              fontWeight: "500",
              lineHeight: "17px",
              letterSpacing: "0em",
              textAlign: "left",
              color: "#7E7E7E",
            }}
          >
            {props.description.slice(0, 200)}...
          </Typography>
        </Stack>
        <Stack
          direction="column"
          spacing={1}
          padding="24px"
          style={{
            backgroundColor: "#F7F7F7",
            borderRadius: "0px 0px 6px 6px",
          }}
        >
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
          >
            <Typography
              style={{
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "17px",
                letterSpacing: "0em",
                textAlign: "left",
                color: "#4A4A4A",
              }}
            >
              Total Subjects: {props.total_subjects_count}
            </Typography>
            <Typography
              style={{
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "17px",
                letterSpacing: "0em",
                textAlign: "left",
                color: "#4A4A4A",
              }}
            >
              Active Subjects: {props.registered_subjects_count}
            </Typography>
          </Stack>
          <Typography
            style={{
              fontSize: "14px",
              fontWeight: "500",
              lineHeight: "17px",
              letterSpacing: "0em",
              textAlign: "left",
              color: "#4A4A4A",
            }}
          >
            Created: {moment(props.created_on).format("D - MMMM - YYYY")}
          </Typography>
        </Stack>
      </Stack>
    </Grid>
  );

  return (
    <Grid
      container
      style={{
        height: "100%",
        backgroundColor: "#fff",
        minHeight: "100vh",
      }}
    >
      <Loading loading={loading}>
        {trials.length ? (
          <>
            <Grid
              item
              xs={12}
              style={{
                backgroundColor: "#fff",
              }}
            >
              <Stack
                direction="column"
                justifyContent="space-between"
                spacing={3}
                // alignItems="center"
                px="58px"
                paddingTop="48px"
                paddingBottom="24px"
                component={Paper}
                elevation={3}
                style={{
                  position: "sticky",
                  top: "0",
                  backgroundColor: "#fff",
                  zIndex: 101,
                  width: "100%",
                }}
              >
                <Typography
                  style={{
                    fontSize: "32px",
                    fontWeight: "700",
                    lineHeight: "38px",
                    letterSpacing: "0em",
                    textAlign: "left",
                  }}
                >
                  Trials
                </Typography>
                <Stack
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="center"
                >
                  <AddTrial />
                </Stack>
              </Stack>

              {/* </Grid> */}
              <Grid
                container
                rowSpacing={4}
                columnSpacing={5}
                marginTop={1}
                px="48px"
                py="32px"
                style={{
                  backgroundColor: "transparent !important",
                  zIndex: 100,
                }}
                // spacing={3}
              >
                {trials.map((item, index) => (
                  <Card key={index} {...item} />
                ))}
              </Grid>
            </Grid>
          </>
        ) : (
          <AddTrial isNew={true} />
        )}
      </Loading>
    </Grid>
  );
}

export default Trials;
