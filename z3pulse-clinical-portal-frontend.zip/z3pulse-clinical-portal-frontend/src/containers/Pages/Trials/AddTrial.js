import { useState } from "react";

import { useDispatch } from "react-redux";
import { setNotify } from "../../../redux/utils/utilsSlice";

import {
  Button,
  FormControl,
  IconButton,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import CustomDialog from "../../../components/CustomDialog";
import {
  CustomInputLabel,
  CustomTextField,
} from "../../../components/CustomTextField";
import { getAuthorization } from "../../../utils/helpers";
import axios from "axios";
import { DOMAIN } from "../../../utils/config";
import NoData from "../../../components/Blockers/NoData";
import AddIcon from "@mui/icons-material/Add";

import chart from "../../../assets/Chart.svg";

export default function AddTrial(props) {
  const [addTrialDialog, setAddTrialDialog] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // redux
  const dispatch = useDispatch();

  const handleAddSubject = async (e) => {
    // handle form submit

    e.preventDefault();
    // remove errors from state, if any
    setError(null);
    // set loading to true
    setLoading(true);

    try {
      // make API request
      await axios({
        method: "POST",
        url: `${DOMAIN}/trials/`,
        data: {
          name,
          description,
        },
        headers: {
          Authorization: getAuthorization(),
        },
      });

      // notify
      dispatch(
        setNotify({
          open: true,
          action: "Successfully created trial",
          severity: "success",
          autoHideDuration: 5000,
          vertical: "bottom",
          horizontal: "right",
        })
      );

      // reload window if suceeded
      window.location.reload();
    } catch (err) {
      // set loading to false
      setLoading(false);
      try {
        // fetch error
        let error_object = JSON.parse(err.request.response);
        console.log(error_object.message);
        // set error
        setError(error_object.message);
      } catch {
        // default error message
        setError("Error while creating trial");
      }
    }
  };

  return (
    <>
      {props.isNew ? (
        <NoData
          message="Looks like you haven't started any trials yet"
          actionText="Start a Trial"
          action={() => setAddTrialDialog(true)}
        />
      ) : (
        <Paper
          onClick={() => setAddTrialDialog(true)}
          elevation={0}
          style={{
            padding: "21px",
            backgroundColor: "#FFFFFF",
            border: "1px solid #F7F7F7",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            spacing={2}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              spacing={1}
            >
              <img src={chart} alt="icon" />
              <Typography
                style={{
                  fontWeight: "500",
                  fontSize: "18px",
                  lineHeight: "22px",
                  color: "#4A4A4A",
                }}
              >
                Start a new trial
              </Typography>
            </Stack>
            <IconButton>
              <AddIcon />
            </IconButton>
          </Stack>
        </Paper>
      )}

      <CustomDialog
        open={addTrialDialog}
        setOpen={setAddTrialDialog}
        title="Start a New Trial"
        content={
          <Stack spacing={2} pt="15px">
            <form autoComplete="off" onSubmit={handleAddSubject}>
              <FormControl fullWidth>
                <CustomInputLabel label="Enter Trial Name" />
                <CustomTextField
                  fullWidth
                  error={error ? true : false}
                  helperText={error}
                  variant="filled"
                  placeholder="Trial Name"
                  type="text"
                  InputProps={{ disableUnderline: true }}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </FormControl>
              <FormControl fullWidth>
                <CustomInputLabel label="Enter Trial Description" />
                <CustomTextField
                  multiline
                  rows={4}
                  fullWidth
                  error={error ? true : false}
                  helperText={error}
                  variant="filled"
                  placeholder="Trial Description"
                  type="text"
                  InputProps={{ disableUnderline: true }}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />
              </FormControl>
              <Button
                disabled={loading}
                type="submit"
                disableElevation
                fullWidth
                variant="contained"
                color="primary"
              >
                {loading ? "Creating Trial" : "Start Trial"}
              </Button>
            </form>
          </Stack>
        }
      />
    </>
  );
}
