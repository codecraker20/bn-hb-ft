import { useEffect } from "react";

import { useDispatch } from "react-redux";
import { setActiveTab } from "../../redux/utils/utilsSlice";

import {
  Container,
  Typography,
  Stack,
  FormControl,
  Button,
} from "@mui/material";

import {
  CustomInputLabel,
  CustomTextField,
} from "../../components/CustomTextField";

export default function Contact() {
  // redux
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setActiveTab("contact"));
  }, [dispatch]);

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <Container
      maxWidth={false}
      style={{
        padding: "48px",

        backgroundColor: "#fff",
        height: "100vh",
      }}
    >
      <Typography
        style={{
          fontSize: "32px",
          fontWeight: "700",
          lineHeight: "38px",
          letterSpacing: "0em",
          textAlign: "left",
        }}
      >
        Contact Us
      </Typography>
      <Stack justifyContent="center" alignItems="center">
        <form
          autoComplete="off"
          onSubmit={handleSubmit}
          style={{
            paddingTop: "90px",
            width: "100%",
            maxWidth: "700px",
          }}
        >
          <Stack my={2} direction="column" spacing={4}>
            <FormControl>
              <CustomInputLabel label="Email ID" />
              <CustomTextField
                fullWidth
                variant="filled"
                placeholder="Email ID"
                type="email"
                InputProps={{ disableUnderline: true }}
                required
              />
            </FormControl>
            <FormControl>
              <CustomInputLabel label="Enter Your Phone No. (Optional)" />
              <CustomTextField
                fullWidth
                variant="filled"
                placeholder="Phone No."
                type="tel"
                InputProps={{ disableUnderline: true }}
              />
            </FormControl>
            <FormControl>
              <CustomInputLabel label="Please Write Your Concern" />
              <CustomTextField
                multiline
                rows={4}
                fullWidth
                variant="filled"
                placeholder="Your Concern"
                type="text"
                InputProps={{ disableUnderline: true }}
                required
              />
            </FormControl>
            <Button
              disableElevation
              type="submit"
              size="large"
              color="primary"
              variant="contained"
            >
              Send
            </Button>
          </Stack>
        </form>
      </Stack>
    </Container>
  );
}
