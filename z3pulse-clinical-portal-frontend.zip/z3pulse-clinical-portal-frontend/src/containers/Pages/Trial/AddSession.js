import { useState } from "react";

import { useDispatch } from "react-redux";
import { setNotify } from "../../../redux/utils/utilsSlice";

import { Button, FormControl, Stack } from "@mui/material";
import CustomDialog from "../../../components/CustomDialog";
import {
  CustomInputLabel,
  CustomTextField,
} from "../../../components/CustomTextField";
import { getAuthorization } from "../../../utils/helpers";
import axios from "axios";
import { DOMAIN } from "../../../utils/config";

export default function AddSession(props) {
  const [open, setOpen] = useState(false);
  const [sessionKey, setSessionKey] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // redux
  const dispatch = useDispatch();

  const handleAddSession = async (e) => {
    // handle form submit

    e.preventDefault();
    // remove errors from state, if any
    setError(null);
    // set loading to true
    setLoading(true);

    try {
      // make API request
      await axios({
        method: "POST",
        url: `${DOMAIN}/trials/sessions/`,
        data: {
          id: props.subject.id,
          session_key: sessionKey,
        },
        headers: {
          Authorization: getAuthorization(),
        },
      });

      // notify
      dispatch(
        setNotify({
          open: true,
          action: "Successfully added session",
          severity: "success",
          autoHideDuration: 5000,
          vertical: "bottom",
          horizontal: "right",
        })
      );

      // reload window if suceeded
      window.location.reload();
    } catch (err) {
      // set loading to false
      setLoading(false);
      try {
        // fetch error
        let error_object = JSON.parse(err.request.response);
        console.log(error_object.message);
        // set error
        setError(error_object.message);
      } catch {
        // default error message
        setError("Error while more adding sessions");
      }
    }
  };

  return (
    <>
      <Button
        style={{ color: "#000", textTransform: "none" }}
        onClick={() => setOpen(true)}
      >
        + &nbsp; Add Session
      </Button>
      <CustomDialog
        open={open}
        setOpen={setOpen}
        title="Add Session"
        content={
          <Stack spacing={2} pt="15px">
            <form autoComplete="off" onSubmit={handleAddSession}>
              <FormControl fullWidth>
                <CustomInputLabel label="Enter Session Key" />
                <CustomTextField
                  fullWidth
                  error={error ? true : false}
                  helperText={error}
                  variant="filled"
                  placeholder="Session Key"
                  type="text"
                  InputProps={{ disableUnderline: true }}
                  value={sessionKey}
                  onChange={(e) => setSessionKey(e.target.value)}
                  required
                />
                <Button
                  disabled={loading}
                  type="submit"
                  disableElevation
                  fullWidth
                  variant="contained"
                  color="primary"
                >
                  {loading ? "Adding Session" : "Add Session"}
                </Button>
              </FormControl>
            </form>
          </Stack>
        }
      />
    </>
  );
}
