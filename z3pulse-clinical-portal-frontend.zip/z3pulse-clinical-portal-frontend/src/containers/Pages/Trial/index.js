import { useEffect, useState, useCallback } from "react";

import { useDispatch } from "react-redux";

import { useParams } from "react-router-dom";
import {
  FolderCopyOutlined,
  NavigateNext,
  TableViewOutlined,
} from "@mui/icons-material";
import {
  Breadcrumbs,
  Grid,
  Stack,
  Typography,
  TextField as TextFieldBase,
  FormControl,
  InputAdornment,
  FormGroup,
  FormControlLabel,
  Paper,
  AccordionSummary,
  AccordionDetails,
  Checkbox,
  Link,
} from "@mui/material";

import MuiAccordion from "@mui/material/Accordion";

import { Search, ExpandMore } from "@mui/icons-material";

import { styled } from "@mui/material/styles";

import Loading from "../../../components/Blockers/Loading";
import axios from "axios";
import { DOMAIN } from "../../../utils/config";
import { getAuthorization } from "../../../utils/helpers";
import AddSubjects from "./AddSubjects";
import NoData from "../../../components/Blockers/NoData";
import { setNotify } from "../../../redux/utils/utilsSlice";
import CustomPagination from "../../../components/CustomPagination";
import AddSession from "./AddSession";
import Test from "./Test";
import DownloadOptions from "./DownloadOptions";

const TextField = styled(TextFieldBase)(({ theme }) => ({
  "& .MuiInputBase-input": {
    paddingTop: "0px",
    padding: "10px",
    fontSize: 16,
  },
}));

const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  "&:not(:last-child)": {
    borderBottom: 0,
  },
  "&:before": {
    display: "none",
  },
}));

function Trial(props) {
  const [loading, setLoading] = useState(true);
  const [loadingSubjects, setLoadingSubjects] = useState(true);

  const [activeOnly, setActiveOnly] = useState(false);
  const [trial, setTrial] = useState({});
  const [subjects, setSubjects] = useState({});
  const [createdHistory, setCreatedHistory] = useState([]);

  const [search, setSearch] = useState("");

  // react-router-dom navigator
  const { id } = useParams();

  // pagination data
  const limit = 10;
  const [page, setPage] = useState(1);

  // redux
  const dispatch = useDispatch();

  useEffect(() => {
    axios({
      method: "GET",
      url: `${DOMAIN}/trials/`,
      params: {
        id,
        deep: false,
      },
      headers: {
        Authorization: getAuthorization(),
      },
    })
      .then((res) => {
        const data = res.data.payload[0];
        setTrial(data);

        if (
          data.metadata &&
          data.metadata.history &&
          data.metadata.history.subject &&
          data.metadata.history.subject.created
        ) {
          setCreatedHistory(data.metadata.history.subject.created);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.log("ERROR:", err);
      });
  }, [id]);

  const fetchSubjects = useCallback(
    (page) => {
      setSubjects({});
      setLoadingSubjects(true);

      axios({
        method: "GET",
        url: `${DOMAIN}/trials/subjects/`,
        params: {
          trial: id,
          page,
          limit,
          deep: true,
          status: activeOnly ? "subject.registered" : null,
          search,
        },
        headers: {
          Authorization: getAuthorization(),
        },
      })
        .then((res) => {
          const data = res.data;

          setSubjects(data);
          setLoadingSubjects(false);
        })
        .catch((err) => {
          console.log("ERROR:", err);
        });
    },
    [id, search, activeOnly]
  );

  useEffect(() => {
    if (page === 1) {
      fetchSubjects(page);
    }
  }, [id, fetchSubjects, page]);

  const breadcrumbs = [
    <Link key="1" href="/">
      <Typography
        sx={{ color: "#2D2D2D", fontSize: "16px", fontWeight: "500" }}
      >
        Trials
      </Typography>
    </Link>,
    <Typography
      key="2"
      sx={{ color: "#2D2D2D", fontSize: "16px", fontWeight: "500" }}
    >
      {trial.name}
    </Typography>,
  ];

  const TestList = (props) => (
    <Stack spacing={3}>
      {props.tests && props.tests.length ? (
        props.tests.map((item, index) => <Test key={index} {...item} />)
      ) : (
        <Typography align="center">No test submitted yet</Typography>
      )}
    </Stack>
  );

  const Session = (props) => (
    <Accordion
      elevation={0}
      style={{
        backgroundColor: "#F7F7F7",
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMore />}
        aria-controls="panel1a-content"
        id="panel1a-header"
        style={{
          padding: "20px 28px",
        }}
      >
        <Typography
          style={{
            fontSize: "18px",
            fontWeight: "600",
            letterSpacing: "0em",
            textAlign: "left",
          }}
        >
          Session ID: {props.session_key}
        </Typography>
      </AccordionSummary>
      <AccordionDetails
        style={{
          borderTop: "0.4px solid #7E7E7E",
          paddingTop: "25px",
        }}
      >
        <TestList tests={props.tests} />
      </AccordionDetails>
    </Accordion>
  );

  const Sessions = (props) => (
    <Stack py={2} px={2} paddingBottom={2} spacing={2}>
      {props.sessions.map((item, index) => (
        <Session key={index} {...item} />
      ))}
    </Stack>
  );

  const Subject = (props) => (
    <Grid item xs={12}>
      <Paper elevation={0}>
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          style={{
            padding: "24px 32px 6px 32px",
          }}
        >
          <Stack
            direction="row"
            justifyContent="flex-start"
            alignItems="center"
            spacing={20}
          >
            <Stack
              direction="column"
              justifyContent="space-between"
              alignItems="flex-start"
              spacing={1}
            >
              <Typography
                style={{
                  fontSize: "16px",
                  fontWeight: "600",
                  lineHeight: "19px",
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#0B3A73",
                }}
              >
                Subject ID: {props.uid}
              </Typography>
              <Typography
                style={{
                  fontSize: "16px",
                  fontWeight: "400",
                  lineHeight: "19px",
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#0B3A73",
                }}
              >
                Secret Key: {props.secret_id}
              </Typography>
            </Stack>
            {props.sessions && props.sessions.length ? null : (
              <Typography
                style={{
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "17px",
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#4A4A4A",
                }}
              >
                This subject has yet to start a session
              </Typography>
            )}
          </Stack>
          <AddSession subject={props} />
        </Stack>
        <Sessions sessions={props.sessions} />
      </Paper>
    </Grid>
  );

  const handleDownloadPDF = ({ data, _case }) => {
    // notify
    dispatch(
      setNotify({
        open: true,
        action: "Fetching PDF",
        severity: "info",
        autoHideDuration: 3000,
        vertical: "bottom",
        horizontal: "right",
      })
    );

    axios({
      method: "GET",
      url: `${DOMAIN}/trials/pdf/download/`,
      params: {
        id,
        created_at_ts: data.created_at_ts,
        start_uid: data.start_uid,
        end_uid: data.end_uid,
        case: _case,
      },
      headers: {
        Authorization: getAuthorization(),
      },
    })
      .then((res) => {
        const file_url = res.data.file_url;

        // notify
        dispatch(
          setNotify({
            open: true,
            action: "Downloading PDF",
            severity: "success",
            autoHideDuration: 3000,
            vertical: "bottom",
            horizontal: "right",
          })
        );

        window.open(file_url, "_blank");
      })
      .catch((err) => {
        dispatch(
          setNotify({
            open: true,
            action: "The PDF is not ready yet, please try after some time.",
            severity: "error",
            autoHideDuration: 5000,
            vertical: "bottom",
            horizontal: "right",
          })
        );
        console.log("ERROR:", err);
      });
  };

  return (
    <Loading loading={loading}>
      <Grid
        container
        style={{
          height: "100%",
          backgroundColor: "#F7F7F7",
          minHeight: "100vh",
        }}
      >
        <Grid
          item
          xs={12}
          style={{
            height: "100%",
          }}
        >
          {/* START: Top Nav */}
          <Stack
            direction="column"
            component={Paper}
            style={{
              position: "sticky",
              top: "0",
              backgroundColor: "#fff",
              zIndex: 101,
            }}
          >
            {/* START: First Row */}
            <Stack
              px="48px"
              py="12px"
              paddingTop="48px"
              direction="row"
              justifyContent="space-between"
              alignItems="center"
            >
              <Typography
                style={{
                  fontSize: "32px",
                  fontWeight: "700",
                  lineHeight: "38px",
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#2D2D2D",
                }}
              >
                {trial.name}
              </Typography>
              <AddSubjects id={id} />
            </Stack>
            {/* END: First Row */}
            {/* START: Second Row */}
            <Stack
              px="48px"
              py="12px"
              direction="row"
              justifyContent="flex-start"
              alignItems="center"
            >
              <Breadcrumbs
                separator={<NavigateNext fontSize="small" />}
                aria-label="breadcrumb"
              >
                {breadcrumbs}
              </Breadcrumbs>
            </Stack>
            {/* END: Second Row */}
            {/* START: Third Row */}
            <Stack
              px="48px"
              py="12px"
              paddingBottom="24px"
              direction="row"
              justifyContent="space-between"
              alignItems="center"
            >
              <Stack
                direction="row"
                spacing={5}
                justifyContent="space-between"
                alignItems="center"
              >
                <FormControl>
                  <TextField
                    fullWidth
                    variant="filled"
                    placeholder="Search using Subject ID"
                    type="text"
                    style={{
                      borderRadius: "16px",
                    }}
                    value={search}
                    onChange={(e) => {
                      setPage(1);
                      setSearch(e.target.value);
                    }}
                    InputProps={{
                      disableUnderline: true,
                      startAdornment: (
                        <InputAdornment position="end">
                          <Search />
                        </InputAdornment>
                      ),
                    }}
                  />
                </FormControl>
                <FormGroup>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={activeOnly}
                        color="primary"
                        style={{ marginRight: "10px" }}
                        onChange={() => {
                          setActiveOnly(!activeOnly);
                          setPage(1);
                          fetchSubjects(1);
                        }}
                      />
                    }
                    label="Show subjects with active sessions"
                  />
                </FormGroup>
              </Stack>
              <Stack direction="row" spacing={2}>
                <DownloadOptions
                  title="Download SOPs"
                  options={createdHistory}
                  onDownload={(item) =>
                    handleDownloadPDF({ data: item, _case: "sop" })
                  }
                  startIcon={<FolderCopyOutlined color="primary" />}
                />
                <DownloadOptions
                  title="Download Subject Table"
                  options={createdHistory}
                  onDownload={(item) =>
                    handleDownloadPDF({ data: item, _case: "subjects-table" })
                  }
                  startIcon={<TableViewOutlined color="primary" />}
                />
              </Stack>
            </Stack>
            {/* END: Third Row */}
          </Stack>
          {/* END: Top Nav */}
          {/* START: Body */}
          <Grid
            container
            px="30px"
            py="20px"
            style={{
              backgroundColor: "transparent !important",
              zIndex: 100,
            }}
            spacing={3}
          >
            {loadingSubjects ? (
              <Loading loading={loadingSubjects} height="70vh" />
            ) : subjects && subjects.payload && subjects.payload.length ? (
              subjects.payload.map((item, index) => (
                <Subject key={index} {...item} />
              ))
            ) : (
              <NoData
                message="Looks like you haven't added any subjects yet"
                height="70vh"
              />
            )}
          </Grid>
          {/* END: Body */}
          {/* START: CustomPagination */}
          {(page > 1 ||
            (subjects.payload && subjects.payload.length >= limit)) && (
            <CustomPagination
              disabled={loadingSubjects}
              last_page_no={subjects.last_page_no}
              limit={subjects.payload && subjects.payload.length}
              page={page}
              handlePaginationChange={(_, value) => {
                fetchSubjects(value);
                setPage(value);
              }}
            />
          )}
          {/* END: CustomPagination */}
        </Grid>
      </Grid>
    </Loading>
  );
}

export default Trial;
