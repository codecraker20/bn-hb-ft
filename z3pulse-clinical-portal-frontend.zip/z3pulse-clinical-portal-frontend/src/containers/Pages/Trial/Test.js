import { useState } from "react";

import { useDispatch } from "react-redux";
import { setNotify } from "../../../redux/utils/utilsSlice";

import { Stack, Typography, Button } from "@mui/material";
import { styled } from "@mui/material/styles";

import moment from "moment";

import axios from "axios";
import { DOMAIN } from "../../../utils/config";
import { getAuthorization } from "../../../utils/helpers";

const ReportButton = styled(Button)({
  boxShadow: "none",
  textTransform: "none",
  fontSize: 16,
  padding: "6px 12px",
  border: "1px solid",
  lineHeight: 1.5,
  backgroundColor: "#fff",
  borderColor: "#fff",
  "&:hover": {
    backgroundColor: "#f9f9f9",
    borderColor: "#f9f9f9",
    boxShadow: "none",
  },
  "&:active": {
    boxShadow: "none",
    backgroundColor: "#f9f9f9",
    borderColor: "#f9f9f9",
  },
  "&:focus": {},
});

function Test(props) {
  const [loadingUserReport, setLoadingUserReport] = useState(false);
  const [loadingClinicianReport, setLoadingClinicianReport] = useState(false);
  const [loadingRawJSON, setLoadingRawJSON] = useState(false);
  const [loadingProcessedJSON, setLoadingProcessedJSON] = useState(false);

  // redux
  const dispatch = useDispatch();

  const download = (reportType) => {
    // notify
    dispatch(
      setNotify({
        open: true,
        action: "Fetching Report",
        severity: "info",
        autoHideDuration: 3000,
        vertical: "bottom",
        horizontal: "right",
      })
    );

    let loader = null;
    let report_format = reportType;
    switch (reportType) {
      case "userReport":
        loader = setLoadingUserReport;
        break;
      case "clinicianReport":
        loader = setLoadingClinicianReport;
        break;
      case "rawJSON":
        loader = setLoadingRawJSON;
        report_format = "raw.json";
        break;
      case "processedJSON":
        loader = setLoadingProcessedJSON;
        report_format = "final.json";
        break;
      default:
        break;
    }

    loader(true);

    axios({
      method: "GET",
      url: `${DOMAIN}/trials/report/download/`,
      params: {
        id: props.id,
        report_format,
      },
      headers: {
        Authorization: getAuthorization(),
      },
    })
      .then((res) => {
        loader(false);

        const file_url = res.data.file_url;

        // notify
        dispatch(
          setNotify({
            open: true,
            action: "Successfully downloaded report",
            severity: "success",
            autoHideDuration: 3000,
            vertical: "bottom",
            horizontal: "right",
          })
        );

        window.open(file_url, "_blank");
      })
      .catch((err) => {
        loader(false);

        dispatch(
          setNotify({
            open: true,
            action: "The Report is not ready yet, please try after some time.",
            severity: "error",
            autoHideDuration: 5000,
            vertical: "bottom",
            horizontal: "right",
          })
        );
        console.log("ERROR:", err);
      });
  };

  return (
    <Stack direction="row" justifyContent="space-between" alignItems="center">
      <Stack direction="row" spacing={20}>
        <Typography
          style={{
            fontSize: "16px",
            fontWeight: "400",
            lineHeight: "19px",
            letterSpacing: "0em",
            textAlign: "left",
            color: "#2D2D2D",
          }}
        >
          {props.test_id}
        </Typography>
        <Typography
          style={{
            fontSize: "16px",
            fontWeight: "400",
            lineHeight: "19px",
            letterSpacing: "0em",
            textAlign: "left",
            color: "#2D2D2D",
          }}
        >
          {moment(props.created_at).format("D-MMMM-YY")}
        </Typography>
      </Stack>
      <div></div>
      <Stack direction="row" spacing={5}>
        <ReportButton
          disabled={loadingUserReport}
          onClick={() => download("userReport")}
        >
          User Report
        </ReportButton>
        <ReportButton
          disabled={loadingClinicianReport}
          onClick={() => download("clinicianReport")}
        >
          Clinician Report
        </ReportButton>
        <ReportButton
          disabled={loadingRawJSON}
          onClick={() => download("rawJSON")}
        >
          Raw JSON
        </ReportButton>
        <ReportButton
          disabled={loadingProcessedJSON}
          onClick={() => download("processedJSON")}
        >
          Processed JSON
        </ReportButton>
      </Stack>
    </Stack>
  );
}

export default Test;
