import { Container, Typography, Button } from "@mui/material";
import { getMobileOperatingSystem } from "../../../utils/helpers";

export default function SessionActivated() {
  const handleOpenApp = () => {
    let url = "";
    switch (getMobileOperatingSystem()) {
      case "android":
        try {
          url =
            "intent://z3pulse.io/#Intent;scheme=Z3Pulse;package=io.neurobit.pulse;end";
        } catch {
          url = "market://details?id=io.neurobit.pulse";
        }
        break;
      case "ios":
        break;
      default:
        return;
    }
    window.location.replace(url);
  };

  return (
    <Container
      maxWidth={false}
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: "48px 20px",
        backgroundColor: "#e2e2e2",
        minHeight: "100vh",
        height: "100%",
      }}
    >
      <Typography
        variant="h5"
        style={{
          textAlign: "center",
        }}
        color="green"
      >
        Session Activated
        <br />
        <br />
        <Button
          disableElevation
          onClick={handleOpenApp}
          variant="contained"
          size="small"
        >
          Open Z3Pulse App
        </Button>
      </Typography>
    </Container>
  );
}
