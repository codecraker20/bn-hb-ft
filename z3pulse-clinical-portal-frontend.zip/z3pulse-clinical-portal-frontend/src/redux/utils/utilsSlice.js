import { createSlice } from "@reduxjs/toolkit";

export const utilsSlice = createSlice({
  name: "utils",
  initialState: {
    loading: false,
    notify: {
      open: false,
      action: null,
      severity: null,
      autoHideDuration: 5000,
      vertical: "bottom",
      horizontal: "right",
    },
    dialog: {
      open: false,
      title: null,
      content: null,
      action: {},
    },
    activeTab: null, // trials, profile, contact
  },
  reducers: {
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setNotify: (state, action) => {
      state.notify = action.payload;
    },
    setDialog: (state, action) => {
      state.dialog = action.payload;
    },
    setActiveTab: (state, action) => {
      state.activeTab = action.payload;
    },
  },
});

export const { setLoading, setActiveTab, setNotify, setDialog } =
  utilsSlice.actions;

export default utilsSlice.reducer;
